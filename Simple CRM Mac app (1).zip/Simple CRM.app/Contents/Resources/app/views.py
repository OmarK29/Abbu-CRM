"""The CRM's pages: Customers (add + list), Log Interaction, Customer History, and Setup."""

from __future__ import annotations

import html
import json
import os
import re
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pandas as pd
import streamlit as st

from sheets import (
    CONFIG_PATH,
    INTERACTION_TYPES,
    CRMStore,
    SetupError,
    clean_phone,
    full_name,
    credentials_path,
    load_config,
    parse_date,
    phone_digits,
    save_config,
    sheet_key_from,
    validate_service_account,
)

# Filled in by app.py on every run so pages can link to each other.
PAGES: dict = {}

TYPE_COLORS = {
    "Call": "#3b82f6",
    "Email": "#a855f7",
    "Meeting": "#22a55a",
    "Site Visit": "#f08c00",
    "Text Message": "#06a6b8",
    "Other": "#8a94a3",
}


# ------------------------------------------------------------------ cached reads

@st.cache_data(ttl=60, show_spinner=False)
def load_customers(_store: CRMStore, sheet_id: str) -> pd.DataFrame:
    return _store.customers()


@st.cache_data(ttl=60, show_spinner=False)
def load_interactions(_store: CRMStore, sheet_id: str) -> pd.DataFrame:
    return _store.interactions()


def refresh_data() -> None:
    load_customers.clear()
    load_interactions.clear()


def _data(store: CRMStore) -> tuple[pd.DataFrame, pd.DataFrame]:
    return load_customers(store, store.sheet.id), load_interactions(store, store.sheet.id)


# ----------------------------------------------------------------------- helpers

def _flash(msg: str, link: str | None = None, link_label: str | None = None) -> None:
    st.session_state["flash"] = {"msg": msg, "link": link, "link_label": link_label}


def _show_flash() -> None:
    flash = st.session_state.pop("flash", None)
    if not flash:
        return
    st.success(flash["msg"], icon=":material/check_circle:")
    if flash.get("link") in PAGES:
        st.page_link(PAGES[flash["link"]], label=flash["link_label"], icon=":material/arrow_forward:")


def _fmt_date(value, long: bool = False) -> str:
    if value is None or pd.isna(value):
        return "—"
    text = f"{value:%b} {value.day}, {value.year}"
    return f"{value:%a}, {text}" if long else text


def _now() -> datetime:
    """Current time in the viewer's time zone (matters when the app is hosted on a UTC server)."""
    try:
        tz = st.context.timezone
        if tz:
            return datetime.now(ZoneInfo(tz)).replace(tzinfo=None)
    except Exception:  # unknown zone name, missing tz database, or no browser context
        pass
    return datetime.now()


def _today() -> date:
    return _now().date()


def _ago(day: date) -> str:
    days = (_today() - day).days
    if days == 0:
        return "today"
    if days == 1:
        return "yesterday"
    if days == -1:
        return "tomorrow"
    if days < 0:
        return f"in {-days} days"
    if days < 14:
        return f"{days} days ago"
    if days < 60:
        return f"{days // 7} weeks ago"
    if days < 730:
        return f"{days // 30} months ago"
    return f"{days // 365} years ago"


FORM_KEYS = {c: "cust_" + c.lower().replace(" ", "_") for c in
             ("First Name", "Middle Name", "Last Name", "Phone", "Email", "Address Line 1", "Address Line 2",
              "City", "State", "ZIP", "Notes")}


def _who(cust) -> str:
    """How to refer to a customer in messages; nothing is required, so fall back to other details."""
    return cust.get("Name") or cust.get("Email") or cust.get("Phone") or cust.get("Customer ID") or "customer"


def _sort_by_name(df: pd.DataFrame) -> pd.DataFrame:
    """Last name, then first name; customers with no name go to the end."""
    key = (df["Last Name"].where(df["Last Name"] != "", df["Name"]).str.lower() + "\x00"
           + df["First Name"].str.lower())
    return df.assign(_k=key.where(df["Name"] != "", "\uffff" + df["Customer ID"])).sort_values("_k").drop(columns="_k")


def _linked_customers(customers: pd.DataFrame) -> pd.DataFrame:
    """Customers that have an ID (rows typed into the sheet without one can't be linked)."""
    linked = customers[customers["Customer ID"] != ""]
    return _sort_by_name(linked).drop_duplicates("Customer ID")


def _customer_picker(customers: pd.DataFrame, key: str) -> str:
    """Customer dropdown that remembers the same customer across all pages."""
    ids = customers["Customer ID"].tolist()
    labels = {
        r["Customer ID"]: f"{r['Name'] or '(no name)'}  ·  {r['Phone'] or r['Email'] or r['Customer ID']}"
        for _, r in customers.iterrows()
    }
    active = st.session_state.get("active_customer_id")
    if active not in ids:
        active = ids[0]
        st.session_state["active_customer_id"] = active
    st.session_state[key] = active

    def _sync():
        st.session_state["active_customer_id"] = st.session_state[key]

    return st.selectbox("Customer", ids, format_func=labels.get, key=key, on_change=_sync)


def _history_for(interactions: pd.DataFrame, customer_id: str, newest_first: bool) -> pd.DataFrame:
    hist = interactions[interactions["Customer ID"] == customer_id].copy()
    hist = hist.sort_values(["when", "logged"], ascending=True, na_position="first", kind="stable")
    hist["number"] = range(1, len(hist) + 1)
    if newest_first:
        hist = hist.iloc[::-1]
    return hist


def _need_customers_first() -> None:
    st.info("No customers yet. Add your first customer, then come back here.", icon=":material/info:")
    st.page_link(PAGES["customers"], label="Add a customer", icon=":material/person_add:")


# ------------------------------------------------------------------- timeline UI

_TIMELINE_CSS = """
<style>
.crm-tl { position: relative; margin: 0.25rem 0 0 0.4rem; padding-left: 1.6rem;
          border-left: 2px solid rgba(128,128,128,0.28); }
.crm-item { position: relative; margin-bottom: 1rem; }
.crm-item:last-child { margin-bottom: 0.25rem; }
.crm-dot { position: absolute; left: calc(-1.6rem - 7px); top: 1.05rem; width: 12px; height: 12px;
           border-radius: 50%; box-shadow: 0 0 0 4px rgba(128,128,128,0.14); }
.crm-card { border: 1px solid rgba(128,128,128,0.25); border-radius: 0.6rem;
            padding: 0.75rem 1rem 0.85rem; background: rgba(128,128,128,0.05); }
.crm-meta { display: flex; flex-wrap: wrap; align-items: center; gap: 0.5rem; font-size: 0.9rem; }
.crm-date { font-weight: 600; }
.crm-chip { font-size: 0.75rem; font-weight: 600; padding: 0.1rem 0.55rem; border-radius: 999px;
            border: 1px solid; }
.crm-ago, .crm-num { opacity: 0.6; font-size: 0.82rem; }
.crm-num { margin-left: auto; }
.crm-body { margin-top: 0.45rem; white-space: pre-wrap; overflow-wrap: anywhere; line-height: 1.55; }
</style>
"""


def _timeline(hist: pd.DataFrame) -> str:
    items = []
    for _, r in hist.iterrows():
        kind = r["Type"] or "Other"
        color = TYPE_COLORS.get(kind, TYPE_COLORS["Other"])
        when = r["when"]
        if pd.isna(when):
            date_txt, ago = html.escape(r["Date"] or "No date"), ""
        else:
            date_txt, ago = _fmt_date(when, long=True), _ago(when.date())
        body = html.escape(r["Content"]) if r["Content"] else "<em style='opacity:.6'>No notes</em>"
        items.append(
            f"<div class='crm-item'><div class='crm-dot' style='background:{color}'></div>"
            f"<div class='crm-card'><div class='crm-meta'>"
            f"<span class='crm-date'>{date_txt}</span>"
            f"<span class='crm-chip' style='color:{color};border-color:{color}66;background:{color}1f'>"
            f"{html.escape(kind)}</span>"
            f"<span class='crm-ago'>{ago}</span><span class='crm-num'>#{r['number']}</span></div>"
            f"<div class='crm-body'>{body}</div></div></div>"
        )
    return _TIMELINE_CSS + "<div class='crm-tl'>" + "".join(items) + "</div>"


# ------------------------------------------------------------------------- pages

def customers_page(store: CRMStore) -> None:
    st.title("Customers")
    _show_flash()
    customers, interactions = _data(store)

    if st.session_state.pop("reset_customer_form", False):
        for k in FORM_KEYS.values():
            st.session_state[k] = ""

    with st.form("add_customer"):
        st.subheader("Add a customer")
        st.caption("Every field is optional. Fill in whatever you have.")
        f = {}
        c1, c2, c3 = st.columns(3)
        f["First Name"] = c1.text_input("First name", key=FORM_KEYS["First Name"], placeholder="Jane")
        f["Middle Name"] = c2.text_input("Middle name", key=FORM_KEYS["Middle Name"])
        f["Last Name"] = c3.text_input("Last name", key=FORM_KEYS["Last Name"], placeholder="Doe")
        c1, c2 = st.columns([2, 3])
        f["Phone"] = c1.text_input("Phone number", key=FORM_KEYS["Phone"], placeholder="(301) 555-0123")
        f["Email"] = c2.text_input("Email address", key=FORM_KEYS["Email"], placeholder="jane@example.com")
        f["Address Line 1"] = st.text_input("Address line 1", key=FORM_KEYS["Address Line 1"], placeholder="123 Main St")
        f["Address Line 2"] = st.text_input("Address line 2", key=FORM_KEYS["Address Line 2"],
                                            placeholder="Apt, suite or unit")
        c1, c2, c3 = st.columns([3, 1, 1.4])
        f["City"] = c1.text_input("City", key=FORM_KEYS["City"], placeholder="Rockville")
        f["State"] = c2.text_input("State", key=FORM_KEYS["State"], placeholder="MD")
        f["ZIP"] = c3.text_input("ZIP code", key=FORM_KEYS["ZIP"], placeholder="20850")
        f["Notes"] = st.text_area("Notes", key=FORM_KEYS["Notes"], height=90,
                                  placeholder="Anything to remember about this customer: preferences, referral source, etc.")
        submitted = st.form_submit_button("Add customer", type="primary", icon=":material/person_add:")

    if submitted:
        f = {k: (v.strip() if k == "Notes" else " ".join(v.split())) for k, v in f.items()}
        if len(f["State"]) == 2:
            f["State"] = f["State"].upper()
        f["Phone"] = clean_phone(f["Phone"])
        name = full_name(f["First Name"], f["Middle Name"], f["Last Name"])
        phone, email, digits = f["Phone"], f["Email"], phone_digits(f["Phone"])
        problems = []
        if not any(f.values()):
            problems.append("Fill in at least one field.")
        if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            problems.append("That email address doesn't look right (expected something like jane@example.com).")
        if phone and not 7 <= len(digits) <= 15:
            problems.append("That phone number doesn't look right (expected 7–15 digits).")
        dupes = customers[
            (customers["Name"].str.lower() == name.lower())
            & (customers["Phone"].map(phone_digits) == digits)
        ]
        if name and not dupes.empty:
            existing = dupes.iloc[0]["Customer ID"] or "no ID"
            problems.append(
                f"{name} with that phone number is already a customer ({existing})." if digits else
                f"A customer named {name} already exists ({existing}). Add a phone number to tell them apart.")
        for p in problems:
            st.error(p, icon=":material/error:")
        if not problems:
            with st.spinner("Saving to Google Sheets…"):
                rec = store.add_customer(f, today=_today())
            refresh_data()
            st.session_state["active_customer_id"] = rec["Customer ID"]
            st.session_state["reset_customer_form"] = True
            who = _who(rec)
            _flash(f"Added {who} ({rec['Customer ID']}).", "log", f"Log an interaction with {who}")
            st.rerun()

    # Customer list, joined with a summary of each customer's interactions.
    st.subheader(f"Customer list ({len(customers)})")
    if customers.empty:
        st.caption("Customers you add appear here and in the Customers tab of your sheet.")
        return
    stats = interactions.groupby("Customer ID").agg(Interactions=("Date", "size"), last=("when", "max"))
    table = customers.merge(stats, how="left", left_on="Customer ID", right_index=True)
    table["Interactions"] = table["Interactions"].fillna(0).astype(int)
    table["Last Contact"] = table["last"]

    query = st.text_input("Search", placeholder="Search name, phone, email, address or notes",
                          label_visibility="collapsed", key="cust_search")
    if query.strip():
        q = query.strip().lower()
        hit = table[["Name", "Address", "Phone", "Email", "Notes", "Customer ID"]].apply(
            lambda col: col.str.lower().str.contains(q, regex=False)).any(axis=1)
        qd = re.sub(r"\D", "", q)
        if len(qd) >= 3:
            hit |= table["Phone"].map(phone_digits).str.contains(qd, regex=False)
        table = table[hit]

    table = _sort_by_name(table)
    shown = table[["Customer ID", "Name", "Phone", "Email", "Address", "Interactions", "Last Contact"]]
    event = st.dataframe(
        shown,
        hide_index=True,
        width="stretch",
        on_select="rerun",
        selection_mode="single-row",
        key="customer_table",
        placeholder="—",
        column_order=["Name", "Phone", "Email", "Address", "Interactions", "Last Contact"],
        column_config={"Last Contact": st.column_config.DateColumn(format="MMM D, YYYY")},
    )
    rows = event.selection.rows if event else []
    if rows:
        picked = shown.iloc[rows[0]]
        c1, c2 = st.columns(2)
        if c1.button(f"View {_who(picked)}'s history", icon=":material/history:", width="stretch"):
            st.session_state["active_customer_id"] = picked["Customer ID"]
            st.switch_page(PAGES["history"])
        if c2.button(f"Log an interaction", icon=":material/edit_note:", width="stretch"):
            st.session_state["active_customer_id"] = picked["Customer ID"]
            st.switch_page(PAGES["log"])
    else:
        st.caption("Select a row to open that customer's history or log an interaction.")


def log_page(store: CRMStore) -> None:
    st.title("Log an interaction")
    _show_flash()
    customers, interactions = _data(store)
    linked = _linked_customers(customers)
    if linked.empty:
        _need_customers_first()
        return

    cid = _customer_picker(linked, key="log_customer")
    cust = linked[linked["Customer ID"] == cid].iloc[0]
    hist = _history_for(interactions, cid, newest_first=True)
    if hist.empty:
        st.caption("No interactions logged with this customer yet.")
    else:
        st.caption(f"{len(hist)} interaction{'s' if len(hist) != 1 else ''} so far · "
                   f"last contact {_fmt_date(hist['when'].max())}")

    if st.session_state.pop("reset_log_form", False):
        st.session_state["log_content"] = ""

    with st.form("log_interaction"):
        c1, c2 = st.columns(2)
        when = c1.date_input("Date of interaction", value=_today(), format="MM/DD/YYYY", key="log_date")
        kind = c2.selectbox("Type", INTERACTION_TYPES, key="log_type")
        content = st.text_area(
            "What happened?", key="log_content", height=160,
            placeholder="e.g. Called about the spring service quote. Wants a follow-up next Tuesday.",
        )
        submitted = st.form_submit_button("Save interaction", type="primary", icon=":material/save:")

    if submitted:
        if not content.strip():
            st.error("Write a few words about the interaction before saving.", icon=":material/error:")
        else:
            with st.spinner("Saving to Google Sheets…"):
                store.add_interaction(cid, cust["Name"], when, kind, content.strip(), logged_at=_now())
            refresh_data()
            st.session_state["reset_log_form"] = True
            _flash(f"Saved {kind.lower()} with {_who(cust)} on {_fmt_date(pd.Timestamp(when))}.",
                   "history", f"See {_who(cust)}'s full history")
            st.rerun()

    if not hist.empty:
        st.markdown("##### Most recent")
        st.html(_timeline(hist.head(3)))
        if len(hist) > 3:
            st.page_link(PAGES["history"], label=f"See all {len(hist)} interactions",
                         icon=":material/arrow_forward:")


def history_page(store: CRMStore) -> None:
    st.title("Customer history")
    _show_flash()
    customers, interactions = _data(store)
    linked = _linked_customers(customers)
    if linked.empty:
        _need_customers_first()
        return

    cid = _customer_picker(linked, key="history_customer")
    cust = linked[linked["Customer ID"] == cid].iloc[0]
    all_hist = _history_for(interactions, cid, newest_first=False)

    with st.container(border=True):
        st.subheader(cust["Name"] or "(no name)")
        details = [f":material/call: {cust['Phone']}" if cust["Phone"] else None,
                   f":material/mail: [{cust['Email']}](mailto:{cust['Email']})" if cust["Email"] else None,
                   f":material/location_on: {cust['Address']}" if cust.get("Address") else None,
                   f"ID {cust['Customer ID']}"]
        added = parse_date(cust["Date Added"])
        if added:
            details.append(f"customer since {_fmt_date(pd.Timestamp(added))}")
        st.caption("  ·  ".join(d for d in details if d))
        if cust["Notes"]:
            st.html("<div style='white-space:pre-wrap;line-height:1.5;padding:0.5rem 0.75rem;border-left:3px solid "
                    "rgba(128,128,128,0.35);background:rgba(128,128,128,0.06);border-radius:0.3rem'>"
                    f"<b>Notes</b><br>{html.escape(cust['Notes'])}</div>")
        m1, m2, m3 = st.columns(3)
        m1.metric("Interactions", len(all_hist))
        m2.metric("First contact", _fmt_date(all_hist["when"].min()) if not all_hist.empty else "—")
        m3.metric("Last contact", _fmt_date(all_hist["when"].max()) if not all_hist.empty else "—")

    if all_hist.empty:
        st.info(f"No interactions logged with {_who(cust)} yet.", icon=":material/info:")
        st.page_link(PAGES["log"], label="Log the first one", icon=":material/edit_note:")
        return

    c1, c2 = st.columns([3, 2], vertical_alignment="center")
    order = c1.radio("Order", ["Newest first", "Oldest first"], horizontal=True,
                     label_visibility="collapsed", key="history_order")
    types = sorted(t for t in all_hist["Type"].unique() if t)
    shown_types = c2.multiselect("Filter by type", types, placeholder="All types",
                                 label_visibility="collapsed", key="history_types")

    hist = _history_for(interactions, cid, newest_first=(order == "Newest first"))
    if shown_types:
        hist = hist[hist["Type"].isin(shown_types)]
    if hist.empty:
        st.caption("No interactions of that type.")
    else:
        st.html(_timeline(hist))

    b1, b2 = st.columns(2)
    b1.page_link(PAGES["log"], label="Log a new interaction", icon=":material/edit_note:")
    export = hist[["Date", "Type", "Content", "Logged At"]]
    safe_name = re.sub(r"[^\w\- ]", "", _who(cust)).strip() or cid
    b2.download_button("Download as CSV", export.to_csv(index=False).encode("utf-8"),
                       file_name=f"{safe_name} - history.csv", mime="text/csv",
                       icon=":material/download:", width="stretch")


def _secrets_toml(sheet_url: str, key: dict) -> str:
    """The text to paste into Streamlit Community Cloud's Secrets box."""
    lines = [f"sheet_url = {json.dumps(sheet_url)}", "", "[gcp_service_account]"]
    lines += [f"{k} = {json.dumps(v)}" for k, v in key.items() if isinstance(v, str)]
    return "\n".join(lines) + "\n"


def _auto_update_settings(cfg: dict) -> None:
    """GitHub repo the launchers download updates from each time the app starts (see updater.py)."""
    st.subheader("Automatic updates")
    version_file = CONFIG_PATH.parent / "code" / ".version"
    running_update = Path(__file__).resolve().parent == (CONFIG_PATH.parent / "code").resolve()
    if cfg.get("update_repo"):
        ver = version_file.read_text().strip()[:7] if version_file.exists() else ""
        st.caption(f"Checks **{cfg['update_repo']}** for updates every time the app starts. "
                   + (f"Running version {ver} from GitHub." if running_update and ver
                      else "Not updated from GitHub yet; the next start will download it."))
    else:
        st.caption("Paste your GitHub repository link to get updates automatically each time the app starts.")
    with st.form("auto_update", border=False):
        repo = st.text_input("GitHub repository", value=cfg.get("update_repo", ""),
                             placeholder="https://github.com/your-name/simple-crm")
        token = st.text_input("Access token (only for a private repository)", value=cfg.get("update_token", ""),
                              type="password", help="GitHub → Settings → Developer settings → Fine-grained tokens. "
                              "Give it read-only access to Contents of this one repository.")
        saved = st.form_submit_button("Save update settings", icon=":material/save:")
    if saved:
        repo = repo.strip()
        if repo and not re.search(r"github\.com[/:][\w.-]+/[\w.-]+|^[\w.-]+/[\w.-]+$", repo):
            st.error("That doesn't look like a GitHub repository link.", icon=":material/error:")
        else:
            cfg = load_config()
            cfg["update_repo"], cfg["update_token"] = repo, token.strip()
            save_config(cfg)
            _flash("Update settings saved. Updates are downloaded the next time the app starts."
                   if repo else "Automatic updates turned off.")
            st.rerun()


def setup_page(store: CRMStore | None, error: str | None, hosted: bool = False) -> None:
    st.title("Connect your Google Sheet")
    if hosted:
        if store is not None:
            st.success(f"Connected to **{store.title}**.", icon=":material/check_circle:")
            st.link_button("Open the sheet", store.url, icon=":material/open_in_new:")
        if error:
            st.error(f"Connecting with the key and sheet link in this app's Secrets failed: {error}",
                     icon=":material/error:")
            if st.button("Try again", type="primary", icon=":material/refresh:"):
                st.cache_resource.clear()
                st.rerun()
        st.caption("This app is hosted, so its Google key and sheet link come from the app's Secrets "
                   "(Streamlit Community Cloud → your app → Settings → Secrets). Change them there.")
        return
    st.write("Everything this CRM saves goes into a Google Sheet you own, in two tabs: "
             "**Customers** and **Interactions**. This one-time setup takes about 5 minutes.")
    _show_flash()
    if store is not None:
        st.success(f"Connected to **{store.title}**.", icon=":material/check_circle:")
        st.link_button("Open the sheet", store.url, icon=":material/open_in_new:")
    if error:
        st.error(f"Your saved key and sheet link were found, but connecting failed: {error}",
                 icon=":material/error:")
        if st.button("Try again", type="primary", icon=":material/refresh:"):
            st.cache_resource.clear()
            st.session_state["just_connected"] = True
            st.rerun()
        st.caption("No need to re-upload anything unless the message says the key or link is wrong.")

    cfg = load_config()
    creds = credentials_path(cfg)
    email = None
    if creds.exists():
        try:
            email = validate_service_account(json.loads(creds.read_text(encoding="utf-8")))
        except (SetupError, ValueError, OSError) as exc:
            st.warning(f"{creds.name} is there but can't be used: {exc}", icon=":material/warning:")

    st.subheader("1. Get a Google key file")
    with st.expander("How to create a service-account key", expanded=email is None):
        st.markdown(
            "1. Go to **[console.cloud.google.com](https://console.cloud.google.com/)** and sign in. "
            "At the top, click the project picker → **New project** → give it any name → **Create**.\n"
            "2. Open **[Google Sheets API](https://console.cloud.google.com/apis/library/sheets.googleapis.com)** "
            "and click **Enable** (check the new project is selected at the top).\n"
            "3. Go to **[IAM & Admin → Service accounts](https://console.cloud.google.com/iam-admin/serviceaccounts)** "
            "→ **Create service account** → name it `crm` → **Done** (skip the optional steps).\n"
            "4. Click the new service account → **Keys** tab → **Add key** → **Create new key** → "
            "**JSON** → **Create**. A `.json` file downloads.\n"
            "5. Upload that file below. Keep it private: it works like a password to your sheet."
        )
    if email:
        st.success(f"Key file loaded. Service account: `{email}`", icon=":material/key:")
    uploaded = st.file_uploader("Replace key file" if email else "Upload the key file (.json)", type=["json"])
    if uploaded is not None and st.session_state.get("processed_upload") != uploaded.file_id:
        st.session_state["processed_upload"] = uploaded.file_id
        try:
            data = json.loads(uploaded.getvalue().decode("utf-8"))
            new_email = validate_service_account(data)
        except (SetupError, ValueError, UnicodeDecodeError) as exc:
            st.error(str(exc) if isinstance(exc, SetupError) else "That file isn't valid JSON.",
                     icon=":material/error:")
        else:
            target = credentials_path({})
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(data, indent=2), encoding="utf-8")
            try:
                os.chmod(target, 0o600)
            except OSError:
                pass
            cfg["credentials_file"] = target.name
            save_config(cfg)
            st.session_state.pop("connect_failure", None)
            st.cache_resource.clear()
            _flash(f"Key saved. Now share your sheet with {new_email}.")
            st.rerun()

    st.subheader("2. Share your sheet with the service account")
    if email:
        st.markdown("Create a blank sheet at **[sheets.new](https://sheets.new)** (or use an existing one), "
                    "click **Share**, and add this address as an **Editor** (untick *Notify people*):")
        st.code(email, language=None)
    else:
        st.caption("Upload the key file first. It contains the email address you share the sheet with.")

    st.subheader("3. Paste the sheet's link")
    url = st.text_input("Google Sheet URL", value=cfg.get("sheet_url", ""),
                        placeholder="https://docs.google.com/spreadsheets/d/…")
    if st.button("Connect", type="primary", icon=":material/link:", disabled=email is None):
        if not sheet_key_from(url):
            st.error("That doesn't look like a Google Sheets link. Copy it from your browser's address bar "
                     "while the sheet is open.", icon=":material/error:")
        else:
            cfg["sheet_url"] = url.strip()
            cfg.setdefault("credentials_file", creds.name)
            save_config(cfg)
            st.session_state.pop("connect_failure", None)
            st.session_state["just_connected"] = True
            st.cache_resource.clear()
            refresh_data()
            st.rerun()
    _auto_update_settings(cfg)
    if email and sheet_key_from(cfg.get("sheet_url", "")):
        with st.expander("Hosting this app online? Copy your Secrets"):
            st.markdown("Paste this into **Secrets** when you deploy on Streamlit Community Cloud. "
                        "It contains your private key, so paste it only there and never into GitHub.")
            st.code(_secrets_toml(cfg["sheet_url"], json.loads(creds.read_text(encoding="utf-8"))),
                    language="toml")
    st.caption("The app creates the Customers and Interactions tabs (with headers) the first time it connects. "
               f"Your key and sheet link are saved in {CONFIG_PATH.parent}, so they're kept between restarts.")
