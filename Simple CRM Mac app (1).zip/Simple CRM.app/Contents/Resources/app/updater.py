"""Auto-update Simple CRM from a GitHub repo. Run by the launchers before the app starts.

Reads "update_repo" (and optional "update_token" for a private repo) from ~/.simple-crm/config.json.
If the repo has a newer commit, downloads it into ~/.simple-crm/code. Prints the folder the app
should run from: the downloaded code if it's usable, otherwise the copy this file came with.
Never fails the launch: any problem (offline, bad link) just means the current version runs.
"""

from __future__ import annotations

import io
import json
import re
import shutil
import ssl
import sys
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = Path.home() / ".simple-crm"
CODE = DATA / "code"
VERSION_FILE = CODE / ".version"
REQUIRED = ("app.py", "sheets.py", "views.py", "requirements.txt")


def log(msg: str) -> None:
    print(f"[updater] {msg}", file=sys.stderr)


def usable(folder: Path) -> bool:
    return all((folder / name).is_file() for name in REQUIRED)


def parse_repo(text: str) -> tuple[str, str] | None:
    text = (text or "").strip()
    m = re.search(r"github\.com[/:]([\w.-]+)/([\w.-]+?)(?:\.git)?(?:[/?#]|$)", text) \
        or re.fullmatch(r"([\w.-]+)/([\w.-]+)", text)
    return (m.group(1), m.group(2)) if m else None


def fetch(url: str, token: str, timeout: int) -> bytes:
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "simple-crm-updater"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        import certifi  # present once the app's packages are installed; avoids Mac certificate errors
        ctx = ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        ctx = ssl.create_default_context()
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout, context=ctx) as r:
        return r.read()


def update() -> Path:
    fallback = CODE if usable(CODE) else HERE
    try:
        cfg = json.loads((DATA / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cfg = {}
    repo = parse_repo(cfg.get("update_repo", ""))
    if not repo:
        return HERE  # auto-update not set up: run the copy that came with the app
    owner, name = repo
    token = (cfg.get("update_token") or "").strip()
    api = f"https://api.github.com/repos/{owner}/{name}"
    try:
        sha = json.loads(fetch(f"{api}/commits/HEAD", token, 10))["sha"]
        current = VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else ""
        if sha == current and usable(CODE):
            log(f"up to date ({sha[:7]})")
            return CODE
        log(f"downloading {owner}/{name} @ {sha[:7]}")
        archive = zipfile.ZipFile(io.BytesIO(fetch(f"{api}/zipball/{sha}", token, 60)))
        staging = DATA / "code.new"
        shutil.rmtree(staging, ignore_errors=True)
        archive.extractall(staging)
        # The app files may sit at the repo root or in a subfolder; use the first folder that has them all.
        found = next((d for d in sorted(staging.rglob("*"), key=lambda p: len(p.parts))
                      if d.is_dir() and usable(d)), None)
        if found is None:
            shutil.rmtree(staging, ignore_errors=True)
            log("repo doesn't contain app.py, sheets.py, views.py and requirements.txt; keeping current version")
            return fallback
        # Keep the settings file (theme, no email prompt) even if it wasn't uploaded to GitHub.
        if not (found / ".streamlit" / "config.toml").exists() and (HERE / ".streamlit" / "config.toml").exists():
            (found / ".streamlit").mkdir(exist_ok=True)
            shutil.copy(HERE / ".streamlit" / "config.toml", found / ".streamlit" / "config.toml")
        (found / ".version").write_text(sha)
        shutil.rmtree(CODE, ignore_errors=True)
        shutil.move(str(found), str(CODE))
        shutil.rmtree(staging, ignore_errors=True)
        log(f"updated to {sha[:7]}")
        return CODE
    except Exception as exc:  # offline, rate-limited, wrong link or token: run what we have
        log(f"update check skipped: {exc}")
        return fallback


if __name__ == "__main__":
    print(update())
